package ajc.formation.soprasteria.projetFinal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjetFinalSpringBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
