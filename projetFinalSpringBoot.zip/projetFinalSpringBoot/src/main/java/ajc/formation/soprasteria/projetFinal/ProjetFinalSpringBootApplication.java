package ajc.formation.soprasteria.projetFinal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjetFinalSpringBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjetFinalSpringBootApplication.class, args);
	}

}
